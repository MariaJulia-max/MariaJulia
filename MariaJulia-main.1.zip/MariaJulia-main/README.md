# MariaJulia
O Stable Diffusion é um mecanismo que usa aprendizagem de máquina para gerar imagens a partir de textos. Mas um desenvolvedor descobriu que a ferramenta também pode ser usada para comprimir uma imagem em um nível que supera padrões como JPEG e WebP. O arquivo resultante até pode ter artefatos visuais, mas em uma proporção baixa.

